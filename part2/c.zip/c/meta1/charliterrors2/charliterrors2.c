\'
'\
'\'
'\\\'
'\\\''
'\\\\'
'\\'
'\ ola ola 
'\'' ola ola
'\   ola ola' 
\' ola ola
'id \\ ola
'id \\ ola ' ola '
' awf \' aef 
'''
''
'aecaec \


'eeee'

'asdad \



    'asd'
    '\\'
