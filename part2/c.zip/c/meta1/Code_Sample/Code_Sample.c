/* este comentario vai
ser ignorado */
//este tbm
int main(){
char a = 'a;
if(a==1){
printf('1');
}
else{
#= a;
}
return 0.012e-12;
}
